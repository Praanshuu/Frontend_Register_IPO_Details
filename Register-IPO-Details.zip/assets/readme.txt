blue icon: #6E7BCF
grey icon: #C4C7DB